from LexAnalyzer import RemoveComments, Tokenize
from Parser import RDP
from SymbolTable import symbolTable

print("All steps were performed without error")
